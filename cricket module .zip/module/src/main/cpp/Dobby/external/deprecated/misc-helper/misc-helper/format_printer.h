#include "common_header.h"

void hexdump(const uint8_t *bytes, size_t len);