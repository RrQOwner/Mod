#pragma once

#ifdef __cplusplus
extern "C" {
#endif

void ClearCache(void *start, void *end);

#ifdef __cplusplus
}
#endif